long ptrace(int request, int pid, void *addr, void *data) {
    return 0;
}